# MSIT task fMRI
AFNI | task fMRI preprocessing + Beta Series Method (BSM) analyses

This code is written in C (utilizing functions from the program AFNI) and is a Beta Series Method (BSM) analyses pipeline. <br><br>
