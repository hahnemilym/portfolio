subjects_list={'test_001' 'test_002'};
for i = 1 : length(subjects_list)
sub=([subjects_list{i}]);
end

